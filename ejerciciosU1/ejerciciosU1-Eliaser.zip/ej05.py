#5 Escribe un programa que pida el importe sin IVA de un artículo y el tipo de IVA a aplicar y calcule e imprima por pantalla el precio final del artículo.
precio = int(input("Dime el precio del articulo: "))
print (precio * 0.21)