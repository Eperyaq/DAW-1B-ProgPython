#7.-Escribe un programa que solicite tres números al usuario y calcule e imprima por pantalla su suma.

print("Dime tres numeros: ")
a=int(input("dime el primero: "))
b=int(input("dime el segundo: "))
c=int(input("dime el tercero: "))
print(a+b+c)