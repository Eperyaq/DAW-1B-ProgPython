#3.-Suponiendo que se han ejecutado las siguientes sentencias de asignación:
ancho = 17
alto = 12.0
print ("1. ancho/2 = " , ancho / 2  )
print ("2. ancho//2 = " , ((ancho / 2) /2) )
print ("3. alto/3 = " , alto / 3  )
print ("4. 1+2*5 = " , 1+2*5 )