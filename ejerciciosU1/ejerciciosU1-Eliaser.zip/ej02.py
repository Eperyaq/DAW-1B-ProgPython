#2.-Escribe un programa para pedirle al usuario las horas de trabajo y el precio por hora y calcule el importe total del servicio.
print("Cuantas horas has trabajado?")
horas = int (input ())
coste = 10
resultado = horas * coste
print("Importe total: " , resultado) 