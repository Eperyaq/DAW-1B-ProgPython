#21 Escribir un programa que pida al usuario que introduzca una frase en la consola y muestre por pantalla la frase invertida.
m= "hola"
print(m[::-1])