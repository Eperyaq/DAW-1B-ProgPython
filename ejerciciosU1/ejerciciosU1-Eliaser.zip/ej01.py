
#1.-Escribe un programa que pida el nombre del usuario para luego darle la bienvenida.
print ("Dime tu nombre")
nombre = input ()
print ("hola, " + nombre)

