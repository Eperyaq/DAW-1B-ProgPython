#10.- Escribir un programa que muestre por pantalla el resultado de la siguiente operación aritmética
resultado= pow(((3+2)/(2*5)), 2)
print(resultado)